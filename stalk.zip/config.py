CONFIG = {
    "id_number": "12346920",
    "targets": [
        {
            "course": "GEARTAP",
            "sections": ["Y11"],
        },
    ],
}
